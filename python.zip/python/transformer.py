import torch 
import torch.nn as nn
import torch.optim as optim 
import os 

class Transformer(nn.Module) : 
  def __init__(self,N ,d_model ,n_hidden ,nhead , name = 'transformer') :
    super(Transformer, self).__init__()
    encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, dim_feedforward = n_hidden, dropout = 0.1)
    
    self.d_model = d_model

    self.embed = nn.Linear(1,d_model)
    self.encoder =  nn.TransformerEncoder(encoder_layer, num_layers = N)
    
    self.fc = nn.Linear(d_model * 17,42)
    self.checkpoint = name

  def forward(self,x  ) : 
    x = x.reshape(-1, 17,1)
    x = self.embed(x.float())
    x = x.permute(1,0,2)
    x = self.encoder(x).long()
    x = x.permute(1, 0,2).reshape(-1, 17 * self.d_model).float()
    out = self.fc(x)
    return out

  def save_checkpoint(self) :
      print('--- Save model checkpoint ---')
      torch.save(self.state_dict(), self.checkpoint)

  def load_checkpoint(self, gpu = True ) :

      print('--- Loading model checkpoint ---')
      if torch.cuda.is_available() and gpu :
          self.load_state_dict(torch.load(self.checkpoint))
      else :
          self.load_state_dict(torch.load(self.checkpoint,map_location=torch.device('cpu')))
